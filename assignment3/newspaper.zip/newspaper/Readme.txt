my homepage is at http://127.0.0.1:8000/content/

Links to articles can be reached from there. /4, /5, /6 (I deleted 1-3)

I migrated 'house' in contributors 